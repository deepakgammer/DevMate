from core.time_parser import parse_time

tests = [
    "remind me in 10 seconds",
    "in 2 minutes",
    "in 1 hour",
    "in 3 days",
    "at 6 pm",
    "at 18:30",
    "today 8 pm",
    "tomorrow 9 am"
]

for t in tests:
    print(t, "->", parse_time(t))
