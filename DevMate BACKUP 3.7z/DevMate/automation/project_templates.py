import os
import subprocess


def create_python_project(name):
    os.makedirs(name, exist_ok=True)
    with open(os.path.join(name, "main.py"), "w") as f:
        f.write('print("Hello from DevMate")\n')
    return f"Python project '{name}' created."


def create_node_project(name):
    os.makedirs(name, exist_ok=True)
    subprocess.run(
        ["npm", "init", "-y"],
        cwd=name,
        shell=True
    )
    return f"Node.js project '{name}' created."
