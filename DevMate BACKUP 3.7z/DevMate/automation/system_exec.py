import os
import subprocess

BASE_PROJECTS_DIR = "projects"


def create_project(language="python"):
    """
    Creates a basic project structure.
    """

    project_name = "demo_project"
    project_path = os.path.join(BASE_PROJECTS_DIR, project_name)

    os.makedirs(project_path, exist_ok=True)

    if language == "python":
        main_file = os.path.join(project_path, "main.py")
        with open(main_file, "w") as f:
            f.write('print("Hello from DevMate")\n')

    return f"Project '{project_name}' created successfully."


def git_init():
    """
    Initializes git repository in current directory.
    """

    try:
        subprocess.run(["git", "init"], check=True)
        return "Git repository initialized successfully."
    except Exception as e:
        return f"Git init failed: {e}"
