import tkinter as tk
from tkinter import scrolledtext
import threading
from datetime import datetime
# -------- Core Systems --------
from core.llm_engine import get_intent
from core.command_parser import normalize_intent
from core.chat_engine import chat_with_devmate
from core.session_manager import Session
from core.listen_engine import listen
from core.voice_engine import speak

# -------- Automation --------
from automation.project_templates import (
    create_python_project,
    create_node_project
)
from automation.system_exec import git_init

# -------- Reminder --------
from core.time_parser import parse_time
from core.reminder_engine import add_reminder
from core.reminder_scheduler import ReminderScheduler


class DevMateGUI:
    """
    DevMate – Production-grade offline developer assistant.
    Supports:
    - Voice + text
    - Automation
    - Reminders
    - Casual + knowledge chat via Ollama
    """

    # ================= INIT =================
    def __init__(self, root):
        self.root = root
        self.root.title("DevMate – Offline Developer Assistant")
        self.root.geometry("760x540")

        self.session = Session()

        # ---- Reminder Scheduler ----
        self.scheduler = ReminderScheduler(interval=5)
        self.scheduler.start()

        # ---- UI ----
        tk.Label(
            root, text="Enter Command:",
            font=("Arial", 12, "bold")
        ).pack(anchor="w", padx=10, pady=5)

        self.input_box = tk.Entry(root, font=("Arial", 12))
        self.input_box.pack(fill="x", padx=10, pady=5)
        self.input_box.bind("<Return>", self.process_command)

        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=6)

        tk.Button(
            btn_frame, text="Run",
            font=("Arial", 11),
            command=self.process_command
        ).pack(side="left", padx=5)

        tk.Button(
            btn_frame, text="🎤 Speak",
            font=("Arial", 11),
            command=self.voice_input
        ).pack(side="left", padx=5)

        tk.Label(
            root, text="DevMate Output:",
            font=("Arial", 12, "bold")
        ).pack(anchor="w", padx=10, pady=5)

        self.output_box = scrolledtext.ScrolledText(
            root, font=("Consolas", 11), height=16
        )
        self.output_box.pack(fill="both", expand=True, padx=10, pady=5)

        self.say("DevMate is ready. How can I assist you?")

    # ================= UTIL =================
    def log(self, msg: str):
        self.output_box.insert(tk.END, msg + "\n")
        self.output_box.see(tk.END)

    def say(self, msg: str):
        msg = self.normalize_numbers_for_speech(
            self.trim_response(msg)
        )
        self.log(msg)
        threading.Thread(
            target=speak,
            args=(msg,),
            daemon=True
        ).start()

    def trim_response(self, text: str) -> str:
        """
        Keep up to 2 short sentences for fast natural speech.
        """
        if not text:
            return text
        text = text.replace("\n", " ").strip()
        parts = [p.strip() for p in text.split(".") if p.strip()]
        trimmed = ". ".join(parts[:2])
        return trimmed + "."

    def clean_voice_text(self, text: str) -> str:
        text = text.lower().strip()
        for noise in ["listening", "listen", "uh", "um"]:
            if text.startswith(noise):
                text = text.replace(noise, "", 1).strip()
        return text

    # ================= NORMALIZERS =================
    def normalize_project_type(self, text: str):
        t = text.lower()
        if any(w in t for w in ["node", "nodejs", "nod", "nord", "note"]):
            return "node"
        if any(w in t for w in ["python", "py", "pyth", "pyton"]):
            return "python"
        return None

    def normalize_confirmation(self, text: str):
        t = text.lower()
        if any(w in t for w in ["yes", "yeah", "ok", "confirm", "proceed"]):
            return "yes"
        if any(w in t for w in ["no", "cancel", "stop", "exit"]):
            return "no"
        return None

    def voice_input(self):
        self.log("🎤 Listening...")
        try:
            spoken_text = listen()
            if spoken_text:
                cleaned = self.clean_voice_text(spoken_text)
                self.log(f"> {cleaned}")
                self.process_text(cleaned)
            else:
                self.say("Microphone not available or audio not clear.")
        except Exception:
            self.say("Microphone error. Please check your audio settings.")

    def process_command(self, event=None):
        user_input = self.input_box.get().strip()
        self.input_box.delete(0, tk.END)
        self.process_text(user_input)

    # ================= CORE =================
    def process_text(self, user_input: str):
        if not user_input:
            return

        text = user_input.lower()
        # ---------------- Date / Time / Day ----------------
        if self.handle_datetime_query(text):
            return



       # ---------- REMINDER FAST PATH ----------
        if "remind me" in text:
            # 🔥 FIX 1: convert number words BEFORE parsing time
            normalized_text = self.normalize_number_words(text)

            trigger = parse_time(normalized_text)
            if not trigger:
                self.say("Please specify the reminder time.")
                return

            msg = normalized_text.replace("remind me", "").strip() or "Reminder"
            add_reminder(msg, trigger)
            self.say("Reminder set successfully.")
            return

        # ---------- GREETINGS ----------
        if any(g in text for g in ["hello", "hi", "hey", "how are you"]):
            self.say("Hello. How can I help you?")
            return

        # ---------- SMALL TALK ----------
        small_talk = {
            "what are you doing": "I am ready to assist you.",
            "what can you do": "I can create projects, manage tasks, and set reminders.",
            "who are you": "I am DevMate, an offline developer assistant."
        }
        for k, v in small_talk.items():
            if k in text:
                self.say(v)
                return

        # ---------- PROJECT SESSION ----------
        if self.session.mode == "project_setup":

            if self.session.project_type is None:
                proj = self.normalize_project_type(text)
                if proj:
                    self.session.project_type = proj
                    self.say("Please provide the project directory name.")
                else:
                    self.say("Please choose Python or Node.")
                return

            if self.session.project_dir is None:
                self.session.project_dir = user_input
                self.session.awaiting_confirmation = True
                self.say(
                    f"Confirm project {self.session.project_type} "
                    f"named {self.session.project_dir}. Proceed?"
                )
                return

            if self.session.awaiting_confirmation:
                decision = self.normalize_confirmation(text)
                if decision == "yes":
                    self.say("Setting up the project.")
                    if self.session.project_type == "python":
                        self.say(create_python_project(self.session.project_dir))
                    else:
                        self.say(create_node_project(self.session.project_dir))
                    self.say("Project setup completed.")
                    self.session.reset()
                elif decision == "no":
                    self.say("Project creation cancelled.")
                    self.session.reset()
                else:
                    self.say("Please say yes or no.")
                return

        raw = get_intent(user_input)
        clean = normalize_intent(raw, user_input)

        intent = clean.get("intent")

        # If intent is None / unknown → CHAT
        SUPPORTED_INTENTS = {
            "create_project",
            "git_init",
            "add_task",
            "set_reminder"
        }

        if intent not in SUPPORTED_INTENTS:
            self.say(chat_with_devmate(user_input))
            return


        # ONLY automation intents handled here
        if intent == "create_project":
            self.session.mode = "project_setup"
            self.say("Which project type do you want?")
            return

        if intent == "git_init":
            self.say("Initializing Git repository.")
            git_init()
            self.say("Git repository ready.")
            return

        if intent == "add_task":
            self.say(f"Task added: {clean.get('task', 'task')}")
            return

        if intent == "set_reminder":
            trigger = parse_time(clean.get("time", ""))
            if not trigger:
                self.say("I could not understand the reminder time.")
                return
            add_reminder(clean.get("message", "Reminder"), trigger)
            self.say("Reminder set successfully.")
            return

        # ---------- OLLAMA FALLBACK (CRITICAL FIX) ----------
        self.say(chat_with_devmate(user_input))

    # ================= SPEECH FIX =================
    def normalize_numbers_for_speech(self, text: str) -> str:
        mapping = {
            " one ": " 1 ", " two ": " 2 ", " three ": " 3 ",
            " four ": " 4 ", " five ": " 5 ", " six ": " 6 ",
            " seven ": " 7 ", " eight ": " 8 ", " nine ": " 9 ",
            " ten ": " 10 "
        }
        for k, v in mapping.items():
            text = text.replace(k, v)
        return text

    def handle_datetime_query(self, text: str) -> bool:
        """
        Handle date / time / day questions locally.
        Returns True if handled.
        """
        now = datetime.now()

        if "time" in text:
            self.say(now.strftime("The time is %I:%M %p."))
            return True

        if "date" in text:
            self.say(now.strftime("Today's date is %B %d, %Y."))
            return True
        if "day" in text:
            self.say(now.strftime("Today is %A."))
            return True

        return False

    def normalize_number_words(self, text: str) -> str:
        mapping = {
        "one": "1",
        "two": "2",
        "three": "3",
        "four": "4",
        "five": "5",
        "six": "6",
        "seven": "7",
        "eight": "8",
        "nine": "9",
        "ten": "10",
        "eleven": "11",
        "twelve": "12"
        }

        for word, num in mapping.items():
            text = text.replace(word, num)

        return text

# ================= ENTRY =================
if __name__ == "__main__":
    root = tk.Tk()
    app = DevMateGUI(root)
    root.mainloop()