from datetime import datetime, timedelta
import time

from core.reminder_engine import init_db, add_reminder
from core.reminder_scheduler import ReminderScheduler

init_db()

add_reminder(
    "This is a scheduled reminder",
    datetime.now() + timedelta(seconds=10)
)

scheduler = ReminderScheduler(interval=2)
scheduler.start()

print("Scheduler running...")
time.sleep(20)
