from datetime import datetime, timedelta
from core.reminder_engine import (
    init_db, add_reminder, get_pending_reminders
)

init_db()

add_reminder(
    "Test reminder",
    datetime.now() + timedelta(seconds=5)
)

print("Waiting...")
reminder_scheduler.py