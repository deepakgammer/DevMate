import subprocess


def chat_with_devmate(user_text: str) -> str:
    """
    Generate a medium-length, professional conversational response
    using Ollama (llama3).

    Used ONLY when no automation intent is detected.
    Optimized for:
    - Natural conversation
    - Fast response
    - Professional tone
    """

    prompt = (
        "You are DevMate, an offline developer assistant.\n"
        "Follow these rules strictly:\n"
        "- Respond in 2 to 4 short sentences\n"
        "- Be professional, friendly, and clear\n"
        "- No slang or emojis\n"
        "- Avoid long explanations unless asked\n"
        "- Do not repeat the user's question\n"
        "- No code unless explicitly requested\n\n"
        f"User: {user_text}\n"
        "DevMate:"
    )

    try:
        result = subprocess.run(
            ["ollama", "run", "llama3"],
            input=prompt,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=40
        )

        reply = result.stdout.strip()

        if not reply:
            return "I can help with that. Please rephrase your question."

        # Controlled trimming: max 4 sentences
        sentences = [s.strip() for s in reply.replace("\n", " ").split(".") if s.strip()]
        trimmed = ". ".join(sentences[:4])

        return trimmed + "."

    except subprocess.TimeoutExpired:
        return "The response took too long. Please try again."

    except Exception:
        return "An internal error occurred while generating the response."
