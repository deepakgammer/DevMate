def normalize_intent(raw: dict, original_text: str = "") -> dict:
    """
    FINAL ultra-robust intent normalizer for DevMate.

    Guarantees:
    - intent is always resolved if possible
    - task is extracted whenever user asked add_task
    - handles unstable / error / partial LLM responses
    """

    result = {"intent": "unknown"}

    # -------------------------------------------------
    # CASE 1: Top-level intent
    # -------------------------------------------------
    if "intent" in raw:
        result["intent"] = raw.get("intent", "unknown")

        # language variants
        if "language" in raw:
            result["language"] = raw["language"]
        if "project_type" in raw:
            result["language"] = raw["project_type"]

        # entities at top level
        if "entities" in raw and isinstance(raw["entities"], dict):
            if "task_name" in raw["entities"]:
                result["task"] = raw["entities"]["task_name"]

        # data block
        if "data" in raw and isinstance(raw["data"], dict):
            data = raw["data"]
            if "task" in data:
                result["task"] = data["task"]
            if "type" in data:
                result["language"] = data["type"]

        # 🔒 ERROR-AWARE FIX: add_task without task
        if result["intent"] == "add_task" and "task" not in result:
            if original_text:
                result["task"] = original_text.replace("add task", "").strip()

        return result

    # -------------------------------------------------
    # CASE 2: response wrapper
    # -------------------------------------------------
    if "response" in raw and isinstance(raw["response"], dict):
        response = raw["response"]

        # explicit intent
        if "intent" in response:
            result["intent"] = response.get("intent", "unknown")

        # git init signals
        if response.get("git_initialized") is True:
            result["intent"] = "git_init"

        # project creation signal
        if "project_name" in response:
            result["intent"] = "create_project"
            result["language"] = "python"

        # error-style responses → fallback to user intent
        if response.get("type") == "ERROR":
            text = original_text.lower()
            if "task" in text:
                result["intent"] = "add_task"
                result["task"] = original_text.replace("add task", "").strip()

        return result

    # -------------------------------------------------
    # CASE 3: result map
    # -------------------------------------------------
    if "result" in raw:
        if isinstance(raw["result"], dict):
            if raw["result"].get("git_init") is True:
                return {"intent": "git_init"}
            if raw["result"].get("add_task") is True:
                return {
                    "intent": "add_task",
                    "task": original_text.replace("add task", "").strip()
                }

        if raw["result"] == "success" and raw.get("intent") == "git_init":
            return {"intent": "git_init"}

    # -------------------------------------------------
    # CASE 4: data.intent + parameters
    # -------------------------------------------------
    if "data" in raw and isinstance(raw["data"], dict):
        data = raw["data"]

        if "intent" in data:
            result["intent"] = data["intent"]

        params = data.get("parameters", {})
        if isinstance(params, dict) and "text" in params:
            result["task"] = params["text"]

        # safety
        if result["intent"] == "add_task" and "task" not in result:
            result["task"] = original_text.replace("add task", "").strip()

        return result

    # -------------------------------------------------
    # FINAL RULE-BASED FALLBACK (NEVER FAILS)
    # -------------------------------------------------
    text = original_text.lower()

    if "project" in text:
        return {"intent": "create_project", "language": "python"}

    if "git" in text:
        return {"intent": "git_init"}

    if "task" in text:
        return {
            "intent": "add_task",
            "task": original_text.replace("add task", "").strip()
        }

    return result
