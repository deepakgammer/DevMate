import numpy as np
import sounddevice as sd
from TTS.api import TTS

# Load TTS once
tts = TTS(model_name="tts_models/en/ljspeech/vits", progress_bar=False)

def get_valid_output_device():
    """
    Return first valid output device index.
    """
    try:
        devices = sd.query_devices()
        for i, d in enumerate(devices):
            if d["max_output_channels"] > 0:
                return i
    except Exception:
        pass
    return None


def speak(text: str):
    """
    Safe non-blocking speech output.
    """
    try:
        if not text:
            return

        wav = tts.tts(text)

        audio = np.array(wav, dtype=np.float32)

        # Force mono shape (N, 1)
        if audio.ndim == 1:
            audio = audio.reshape(-1, 1)

        device = get_valid_output_device()
        if device is None:
            return

        sd.default.device = (None, device)

        sd.play(audio, samplerate=22050)
        sd.wait()

    except Exception as e:
        print("🔊 Speak error:", e)
