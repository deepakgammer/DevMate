import time
import threading

from core.reminder_engine import (
    init_db,
    get_pending_reminders,
    mark_triggered
)
from core.voice_engine import speak


class ReminderScheduler:
    """
    Background scheduler to trigger reminders.
    """

    def __init__(self, interval: int = 5):
        self.interval = interval
        self.running = False
        self.thread = None

    def start(self):
        if self.running:
            return

        init_db()
        self.running = True
        self.thread = threading.Thread(
            target=self._run,
            daemon=True
        )
        self.thread.start()

    def _run(self):
        while self.running:
            reminders = get_pending_reminders()

            for reminder_id, message in reminders:
                speak(f"Reminder. {message}")
                mark_triggered(reminder_id)

            time.sleep(self.interval)

    def stop(self):
        self.running = False
