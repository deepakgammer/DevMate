import sqlite3
from datetime import datetime
from pathlib import Path

DB_PATH = Path("data/reminders.db")


def init_db():
    """
    Initialize reminder database.
    """
    DB_PATH.parent.mkdir(exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message TEXT NOT NULL,
            trigger_time TEXT NOT NULL,
            triggered INTEGER DEFAULT 0
        )
    """)

    conn.commit()
    conn.close()


def add_reminder(message: str, trigger_time: datetime):
    """
    Add a new reminder.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO reminders (message, trigger_time) VALUES (?, ?)",
        (message, trigger_time.isoformat())
    )

    conn.commit()
    conn.close()


def get_pending_reminders():
    """
    Fetch reminders that are due and not triggered.
    """
    now = datetime.now().isoformat()

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, message FROM reminders
        WHERE trigger_time <= ? AND triggered = 0
    """, (now,))

    rows = cursor.fetchall()
    conn.close()

    return rows


def mark_triggered(reminder_id: int):
    """
    Mark reminder as triggered.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE reminders SET triggered = 1 WHERE id = ?",
        (reminder_id,)
    )

    conn.commit()
    conn.close()
