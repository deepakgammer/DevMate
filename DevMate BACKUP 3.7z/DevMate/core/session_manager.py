class Session:
    """
    Maintains conversational state for multi-step workflows.

    Supported flows:
    - Project setup
    - Reminder setup
    - Confirmation handling
    """

    def __init__(self):
        self.reset()

    def reset(self):
        # -----------------------------
        # Global session state
        # -----------------------------
        self.mode = None
        # Possible values:
        # "project_setup"
        # "reminder_setup"

        # -----------------------------
        # Project setup state
        # -----------------------------
        self.project_type = None      # "python" | "node"
        self.project_dir = None       # folder name
        self.awaiting_confirmation = False

        # -----------------------------
        # Reminder setup state
        # -----------------------------
        self.reminder_time = None     # datetime object
        self.reminder_message = None # reminder text

    # -----------------------------
    # Helpers (optional but clean)
    # -----------------------------
    def start_project_setup(self):
        self.reset()
        self.mode = "project_setup"

    def start_reminder_setup(self):
        self.reset()
        self.mode = "reminder_setup"

    def is_active(self):
        return self.mode is not None

    def awaiting_user_confirmation(self):
        return self.awaiting_confirmation is True
