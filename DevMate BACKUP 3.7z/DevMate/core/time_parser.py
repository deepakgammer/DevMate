from datetime import datetime, timedelta
import re


def parse_time(text: str):
    """
    Parse natural language time expressions into datetime.
    Returns datetime object or None if not understood.

    Supported examples:
    - in 10 seconds
    - in 5 minutes
    - in 2 hours
    - in 1 day
    - at 6 pm
    - at 18:30
    - today 8 pm
    - tomorrow 9 am
    """

    if not text:
        return None

    text = text.lower().strip()
    now = datetime.now()

    # -------------------------------------------------
    # in X seconds
    # -------------------------------------------------
    match = re.search(r"in (\d+) second", text)
    if match:
        return now + timedelta(seconds=int(match.group(1)))

    # -------------------------------------------------
    # in X minutes
    # -------------------------------------------------
    match = re.search(r"in (\d+) minute", text)
    if match:
        return now + timedelta(minutes=int(match.group(1)))

    # -------------------------------------------------
    # in X hours
    # -------------------------------------------------
    match = re.search(r"in (\d+) hour", text)
    if match:
        return now + timedelta(hours=int(match.group(1)))

    # -------------------------------------------------
    # in X days
    # -------------------------------------------------
    match = re.search(r"in (\d+) day", text)
    if match:
        return now + timedelta(days=int(match.group(1)))

    # -------------------------------------------------
    # at HH[:MM] [am/pm]
    # -------------------------------------------------
    match = re.search(r"at (\d{1,2})(?::(\d{2}))?\s*(am|pm)?", text)
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2)) if match.group(2) else 0
        period = match.group(3)

        if period == "pm" and hour < 12:
            hour += 12
        if period == "am" and hour == 12:
            hour = 0

        trigger = now.replace(
            hour=hour, minute=minute, second=0, microsecond=0
        )

        # if time already passed today → tomorrow
        if trigger <= now:
            trigger += timedelta(days=1)

        return trigger

    # -------------------------------------------------
    # today HH[:MM] [am/pm]
    # -------------------------------------------------
    match = re.search(r"today (\d{1,2})(?::(\d{2}))?\s*(am|pm)?", text)
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2)) if match.group(2) else 0
        period = match.group(3)

        if period == "pm" and hour < 12:
            hour += 12
        if period == "am" and hour == 12:
            hour = 0

        trigger = now.replace(
            hour=hour, minute=minute, second=0, microsecond=0
        )

        return trigger

    # -------------------------------------------------
    # tomorrow HH[:MM] [am/pm]
    # -------------------------------------------------
    match = re.search(r"tomorrow (\d{1,2})(?::(\d{2}))?\s*(am|pm)?", text)
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2)) if match.group(2) else 0
        period = match.group(3)

        if period == "pm" and hour < 12:
            hour += 12
        if period == "am" and hour == 12:
            hour = 0

        return (now + timedelta(days=1)).replace(
            hour=hour, minute=minute, second=0, microsecond=0
        )

    return None
