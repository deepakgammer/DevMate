import sounddevice as sd
import numpy as np
import whisper
import tempfile
import soundfile as sf
import os

# Load Whisper once
model = whisper.load_model("base")

def get_valid_input_device():
    """
    Return first valid microphone device index.
    """
    try:
        devices = sd.query_devices()
        for i, d in enumerate(devices):
            if d["max_input_channels"] > 0:
                return i
    except Exception:
        pass
    return None


def listen(duration=5, samplerate=16000):
    """
    Safe microphone capture + Whisper transcription.
    NEVER crashes UI.
    """
    try:
        device = get_valid_input_device()
        if device is None:
            return None

        sd.default.device = (device, None)

        audio = sd.rec(
            int(duration * samplerate),
            samplerate=samplerate,
            channels=1,
            dtype="float32"
        )
        sd.wait()

        audio = np.squeeze(audio)

        # Save temp wav correctly
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            temp_path = f.name
            sf.write(temp_path, audio, samplerate)

        result = model.transcribe(temp_path)
        os.remove(temp_path)

        text = result.get("text", "").strip()
        return text if text else None

    except Exception as e:
        print("🎤 Listen error:", e)
        return None
