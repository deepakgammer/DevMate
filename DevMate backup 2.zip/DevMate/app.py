from core.llm_engine import get_intent
from core.command_parser import normalize_intent
from automation.system_exec import create_project, git_init

commands = [
    "create python project",
    "initialize git repository",
    "add task finish login UI"
]

for cmd in commands:
    raw = get_intent(cmd)
    clean = normalize_intent(raw, cmd)

    print(clean)

    intent = clean.get("intent", "unknown")

    if intent == "create_project":
        language = clean.get("language", "python")
        print(create_project(language))

    elif intent == "git_init":
        print(git_init())

    elif intent == "add_task":
        task = clean.get("task", "undefined task")
        print("Task received:", task)
