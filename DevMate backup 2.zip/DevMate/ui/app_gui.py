import tkinter as tk
from tkinter import scrolledtext
import threading

from core.llm_engine import get_intent
from core.command_parser import normalize_intent
from core.chat_engine import chat_with_devmate
from core.session_manager import Session
from core.listen_engine import listen
from core.voice_engine import speak

from automation.project_templates import (
    create_python_project,
    create_node_project
)
from automation.system_exec import git_init


class DevMateGUI:
    """
    DevMate – Production-level offline developer assistant GUI.
    Fast, natural, voice + text interaction with safe automation.
    """

    def __init__(self, root):
        self.root = root
        self.root.title("DevMate – Offline Developer Assistant")
        self.root.geometry("760x540")

        self.session = Session()

        # ---------------- UI ----------------
        tk.Label(
            root, text="Enter Command:",
            font=("Arial", 12, "bold")
        ).pack(anchor="w", padx=10, pady=5)

        self.input_box = tk.Entry(root, font=("Arial", 12))
        self.input_box.pack(fill="x", padx=10, pady=5)
        self.input_box.bind("<Return>", self.process_command)

        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=6)

        tk.Button(
            btn_frame, text="Run",
            font=("Arial", 11),
            command=self.process_command
        ).pack(side="left", padx=5)

        tk.Button(
            btn_frame, text="🎤 Speak",
            font=("Arial", 11),
            command=self.voice_input
        ).pack(side="left", padx=5)

        tk.Label(
            root, text="DevMate Output:",
            font=("Arial", 12, "bold")
        ).pack(anchor="w", padx=10, pady=5)

        self.output_box = scrolledtext.ScrolledText(
            root, font=("Consolas", 11), height=16
        )
        self.output_box.pack(fill="both", expand=True, padx=10, pady=5)

        self.say("DevMate is ready. How can I assist you?")

    # ---------------- Utility ----------------
    def log(self, message: str):
        self.output_box.insert(tk.END, message + "\n")
        self.output_box.see(tk.END)

    def say(self, message: str):
        message = self.trim_response(message)
        self.log(message)
        threading.Thread(
            target=speak,
            args=(message,),
            daemon=True
        ).start()

    def trim_response(self, text: str) -> str:
        if not text:
            return text
        sentences = text.replace("\n", " ").split(".")
        trimmed = ".".join(sentences[:2]).strip()
        if not trimmed.endswith("."):
            trimmed += "."
        return trimmed

    def clean_voice_text(self, text: str) -> str:
        text = text.lower().strip()
        for noise in ["listening", "listen", "uh", "um"]:
            if text.startswith(noise):
                text = text.replace(noise, "", 1).strip()
        return text

    # ---------------- Normalizers ----------------
    def normalize_project_type(self, text: str):
        text = text.lower().replace("-", "").replace(".", "").strip()

        node_variants = ["node", "nodejs", "nod", "nord", "note", "norde"]
        python_variants = ["python", "py", "pyth", "pyton"]

        if any(word in text for word in node_variants):
            return "node"
        if any(word in text for word in python_variants):
            return "python"
        return None

    def normalize_confirmation(self, text: str):
        text = text.lower().strip()

        yes_variants = [
            "yes", "yes.", "yeah", "yep", "yup",
            "ok", "okay", "confirm", "proceed"
        ]
        no_variants = [
            "no", "no.", "nope", "nah", "cancel", "stop", "exit"
        ]

        if any(word == text or word in text for word in yes_variants):
            return "yes"
        if any(word == text or word in text for word in no_variants):
            return "no"
        return None

    # ---------------- Voice Input ----------------
    def voice_input(self):
        self.log("🎤 Listening...")
        spoken_text = listen()

        if spoken_text:
            cleaned = self.clean_voice_text(spoken_text)
            self.log(f"> {cleaned}")
            self.process_text(cleaned)
        else:
            self.say("I could not hear you clearly.")

    # ---------------- Text Input ----------------
    def process_command(self, event=None):
        user_input = self.input_box.get().strip()
        self.input_box.delete(0, tk.END)
        self.process_text(user_input)

    # ---------------- Core Logic ----------------
    def process_text(self, user_input: str):
        if not user_input:
            return

        text = user_input.lower()

        # =====================================================
        # FAST LOCAL GREETINGS
        # =====================================================
        greetings = [
            "hello", "hi", "hey", "hello devmate",
            "how are you", "good morning", "good evening"
        ]

        if any(greet in text for greet in greetings):
            self.say("Hello. How can I help you?")
            return

        # =====================================================
        # FAST LOCAL SMALL TALK
        # =====================================================
        small_talk = {
            "what are you doing": "I’m ready and waiting to assist you.",
            "what can you do": "I can create projects, manage tasks, and automate workflows.",
            "who are you": "I am DevMate, an offline developer assistant.",
            "who is the president": "I do not have real-time data, but I can help with development tasks.",
            "are you real": "I am a software-based assistant designed to help developers."
        }

        for key, response in small_talk.items():
            if key in text:
                self.say(response)
                return

        # =====================================================
        # ACTIVE PROJECT SETUP SESSION
        # =====================================================
        if self.session.mode == "project_setup":

            if self.session.project_type is None:
                normalized = self.normalize_project_type(text)
                if normalized:
                    self.session.project_type = normalized
                    self.say("Please provide the project directory name.")
                else:
                    self.say("Please choose Python or Node.")
                return

            if self.session.project_dir is None:
                self.session.project_dir = user_input
                self.session.awaiting_confirmation = True
                self.say(
                    f"Confirm project: {self.session.project_type} – "
                    f"{self.session.project_dir}. Proceed?"
                )
                return

            if self.session.awaiting_confirmation:
                decision = self.normalize_confirmation(text)

                if decision == "yes":
                    self.say("Setting up the project.")

                    if self.session.project_type == "python":
                        self.say(create_python_project(self.session.project_dir))
                    elif self.session.project_type == "node":
                        self.say(create_node_project(self.session.project_dir))

                    self.say("Project setup completed.")
                    self.session.reset()

                elif decision == "no":
                    self.say("Project creation cancelled.")
                    self.session.reset()

                else:
                    self.say("Please say yes or no.")
                return

        # =====================================================
        # INTENT DETECTION
        # =====================================================
        raw = get_intent(user_input)
        clean = normalize_intent(raw, user_input)
        intent = clean.get("intent", "unknown")

        if intent == "create_project":
            self.session.mode = "project_setup"
            self.say("Which project type do you want?")
            return

        if intent == "git_init":
            self.say("Initializing Git repository.")
            git_init()
            self.say("Git repository ready.")
            return

        if intent == "add_task":
            task = clean.get("task", "undefined task")
            self.say(f"Task added: {task}")
            return

        # =====================================================
        # NORMAL CONVERSATION (LLM)
        # =====================================================
        reply = chat_with_devmate(user_input)
        self.say(reply)


# ---------------- App Entry ----------------
if __name__ == "__main__":
    root = tk.Tk()
    app = DevMateGUI(root)
    root.mainloop()
