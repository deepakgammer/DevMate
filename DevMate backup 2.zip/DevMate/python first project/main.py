print("Hello from DevMate")
