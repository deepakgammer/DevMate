from TTS.api import TTS
import sounddevice as sd
import numpy as np

# Faster, lighter voice model
tts = TTS(
    model_name="tts_models/en/ljspeech/vits",
    progress_bar=False,
    gpu=False
)

def speak(text: str):
    """
    Fast, natural TTS optimized for short responses.
    """
    if not text:
        return

    # 🔥 Speed control (1.0 = normal, 1.2–1.4 = faster)
    wav = tts.tts(
        text,
        speaker=None,
        speed=1.25   # <<< KEY CHANGE
    )

    sd.play(np.array(wav), samplerate=22050)
    sd.wait()
