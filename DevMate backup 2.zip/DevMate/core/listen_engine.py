import whisper
import sounddevice as sd
import numpy as np
import time

# Load Whisper model once
# small = best balance for CPU + accuracy
model = whisper.load_model("small")


def listen(duration=5):
    """
    Whisper microphone listener WITHOUT ffmpeg.
    Uses raw numpy audio directly.
    This FIXES WinError 2 permanently.
    """

    samplerate = 16000
    channels = 1

    print("🎤 Listening (Whisper – python-only)...")

    # Record audio
    audio = sd.rec(
        int(duration * samplerate),
        samplerate=samplerate,
        channels=channels,
        dtype="float32"
    )
    sd.wait()

    # Convert to mono numpy array
    audio = np.squeeze(audio)

    # 🔥 KEY FIX: pass numpy array directly
    result = model.transcribe(
        audio,
        language="en",
        fp16=False
    )

    text = result.get("text", "").strip()
    print("📝 Whisper heard:", text)

    return text
