import subprocess


def chat_with_devmate(user_text: str) -> str:
    """
    Generate a medium-length, professional conversational response
    using Ollama (llama3).

    Used ONLY when no automation intent is detected.
    Balanced for:
    - Natural conversation
    - Fast response
    - Professional tone
    """

    prompt = f"""
You are DevMate, an offline developer assistant.

GUIDELINES:
- Respond in 2 to 4 short sentences
- Be professional, friendly, and clear
- No slang or emojis
- Avoid long explanations unless the user asks
- Do not repeat the user's question
- No code unless explicitly requested
- Keep responses concise and helpful

User: {user_text}
DevMate:
"""

    try:
        result = subprocess.run(
            [
                "ollama",
                "run",
                "llama3",
                "--temperature", "0.4"
            ],
            input=prompt,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=30
        )

        reply = result.stdout.strip()

        if not reply:
            return "I’m not fully sure I understood that. Could you please clarify?"

        # 🔒 Controlled trimming: max 4 sentences
        sentences = reply.replace("\n", " ").split(".")
        trimmed = ".".join(sentences[:4]).strip()

        if not trimmed.endswith("."):
            trimmed += "."

        return trimmed

    except subprocess.TimeoutExpired:
        return "That took a bit longer than expected. Please try again."

    except Exception:
        return "An internal error occurred. Please try again."
