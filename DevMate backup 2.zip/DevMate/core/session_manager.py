class Session:
    """
    Maintains conversational state for multi-step workflows.
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self.mode = None              # e.g., "project_setup"
        self.project_type = None      # python / node
        self.project_dir = None       # folder name
        self.awaiting_confirmation = False
