import subprocess


def chat_with_devmate(user_text: str) -> str:
    """
    Uses Ollama (llama3) to generate conversational response.
    This is used ONLY when intent is unknown.
    """

    prompt = (
        "You are DevMate, a friendly offline developer assistant. "
        "Respond casually and clearly. "
        "Do not give code unless asked. "
        f"User says: {user_text}"
    )

    try:
        result = subprocess.run(
            ["ollama", "run", "llama3", prompt],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=60
        )

        reply = result.stdout.strip()

        if not reply:
            return "Hmm 🤔 naan kekkura vishayam purinjikka mudiyala da."

        return reply

    except Exception:
        return "Sorry da machaa 😅 konjam glitch aagiduchu."
