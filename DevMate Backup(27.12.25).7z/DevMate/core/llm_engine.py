import subprocess
import json
import re


def get_intent(user_input: str) -> dict:
    """
    Robust intent extraction using Ollama (Windows-safe, production style)
    """

    prompt = (
        "You are a command parser. "
        "Return JSON only. "
        "Supported intents: create_project, git_init, add_task. "
        f"Command: {user_input}"
    )

    try:
        result = subprocess.run(
            ["ollama", "run", "llama3", prompt],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=60
        )

        output = result.stdout.strip()
        print("RAW:", output)  # debug for now

        # 🔍 Extract JSON using regex (ANYWHERE in text)
        match = re.search(r"\{.*\}", output)

        if match:
            return json.loads(match.group())

    except Exception as e:
        print("LLM ERROR:", e)

    # 🔁 FALLBACK (LLM SAFETY NET)
    text = user_input.lower()

    if "create" in text and "project" in text:
        return {"intent": "create_project", "language": "python"}

    if "git" in text:
        return {"intent": "git_init"}

    if "task" in text:
        return {"intent": "add_task", "task": user_input}

    return {"intent": "unknown"}
