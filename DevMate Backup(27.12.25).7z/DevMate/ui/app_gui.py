import tkinter as tk
from tkinter import scrolledtext

from core.llm_engine import get_intent
from core.command_parser import normalize_intent
from automation.system_exec import create_project, git_init
from core.chat_engine import chat_with_devmate



class DevMateGUI:

    def __init__(self, root):
        self.root = root
        self.root.title("DevMate – Offline Developer Assistant")
        self.root.geometry("700x450")

        # ------------------------
        # Input Label
        # ------------------------
        tk.Label(
            root,
            text="Enter Command:",
            font=("Arial", 12, "bold")
        ).pack(anchor="w", padx=10, pady=5)

        # ------------------------
        # Input Box
        # ------------------------
        self.input_box = tk.Entry(root, font=("Arial", 12))
        self.input_box.pack(fill="x", padx=10, pady=5)
        self.input_box.bind("<Return>", self.process_command)

        # ------------------------
        # Run Button
        # ------------------------
        tk.Button(
            root,
            text="Run Command",
            font=("Arial", 11),
            command=self.process_command
        ).pack(pady=8)

        # ------------------------
        # Output Label
        # ------------------------
        tk.Label(
            root,
            text="DevMate Output:",
            font=("Arial", 12, "bold")
        ).pack(anchor="w", padx=10, pady=5)

        # ------------------------
        # Output Box
        # ------------------------
        self.output_box = scrolledtext.ScrolledText(
            root,
            font=("Consolas", 11),
            height=12
        )
        self.output_box.pack(fill="both", expand=True, padx=10, pady=5)

        self.log("DevMate is ready. Type a command.")

    # --------------------------------
    # Logger
    # --------------------------------
    def log(self, message):
        self.output_box.insert(tk.END, message + "\n")
        self.output_box.see(tk.END)

    # --------------------------------
    # Main Command Processor
    # --------------------------------
    def process_command(self, event=None):
        user_input = self.input_box.get().strip()

        if not user_input:
            return

        self.log(f"> {user_input}")

        # Clear input
        self.input_box.delete(0, tk.END)

        # ------------------------
        # AI Processing
        # ------------------------
        raw = get_intent(user_input)
        clean = normalize_intent(raw, user_input)

        self.log(f"Intent Detected: {clean}")

        intent = clean.get("intent", "unknown")

        # ------------------------
        # Automation Actions
        # ------------------------
        if intent == "create_project":
            language = clean.get("language", "python")
            result = create_project(language)
            self.log(result)

        elif intent == "git_init":
            result = git_init()
            self.log(result)

        elif intent == "add_task":
            task = clean.get("task", "undefined task")
            self.log(f"Task Added: {task}")

        else:
            self.log("DevMate is thinking 🤔...")
            reply = chat_with_devmate(user_input)
            self.log(reply)

def chat_response(text: str) -> str:
    text = text.lower()

    if any(word in text for word in ["hi", "hello", "hey"]):
        return "Hey machaa 😄! Enna help venum?"

    if "how are you" in text:
        return "Nalla irukken da 😎. DevMate ready to help!"

    if any(word in text for word in ["who are you", "what are you"]):
        return "Naan DevMate 🤖 — un offline developer assistant."

    if any(word in text for word in ["thanks", "thank you"]):
        return "Always da machaa ❤️"

    if "help" in text:
        return (
            "You can say things like:\n"
            "- create python project\n"
            "- initialize git repository\n"
            "- add task finish login UI"
        )

    return "Hmm 🤔 puriyala da, but naan inga irukken. Try a dev command!"

# --------------------------------
# App Entry Point
# --------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = DevMateGUI(root)
    root.mainloop()
