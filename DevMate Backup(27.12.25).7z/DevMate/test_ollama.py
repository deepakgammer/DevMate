import subprocess

result = subprocess.run(
    ["ollama", "run", "llama3", "say hello"],
    capture_output=True,
    text=True,
    encoding="utf-8",
    errors="ignore"
)

print("STDOUT:")
print(result.stdout)

print("STDERR:")
print(result.stderr)
